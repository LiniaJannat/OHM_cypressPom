
import Login from "../fixtures/pom/login";
import Recruit from "../fixtures/pom/Recruitment";



describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
      const ln = new Login();
      ln.SetUsername("Admin");
      ln.SetPassword("admin123");
      ln.Clicklog();

      const ln1 = new Recruit ()
      ln1.clickRec ();
     ln1.clickadd ();
     ln1.clickFname("Test");
      ln1.clickMname("1");
      ln1.clickLname ();
      cy.wait (3000);
        ln1.clickdop ();
        cy.wait(3000);
        ln1.clickEmail ();
        ln1.clickCbox ();
        ln1.clicksave ();
    });
  });
  