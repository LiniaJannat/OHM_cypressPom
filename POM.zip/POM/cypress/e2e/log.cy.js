import Login from "../fixtures/pom/login"
//import Recruit from "../fixtures/pom/Recruitmentecruitment"  // Use a unique variable name like "Recruitment" for clarity

describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');

    const ln = new Login();
    ln.SetUsername("Admin");
    ln.SetPassword("admin123");
    ln.Clicklog();
  });
});

