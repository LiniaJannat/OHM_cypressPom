import Testclaim from "../fixtures/claim";
import Login from "../fixtures/pom/login";


describe('template spec', () => {
    it('passes', () => {
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
  
      const ln = new Login();
      ln.SetUsername("Admin");
      ln.SetPassword("admin123");
      ln.Clicklog();

     const ln3 = new Testclaim ();
     ln3.ClickCl ();
        ln3.ClickAss ();

        ln3.ClickEm ();
        ln3.clickevent ();

    });
  });
  