

class Testclaim {


    ClickCl (){
        cy.get(':nth-child(11) > .oxd-main-menu-item').click ();
    }

    ClickAss (){
        cy.get('.orangehrm-header-container > .oxd-button').click ()
    }
     
    ClickEm (){
        cy.get('.oxd-autocomplete-text-input > input').type ("HInts")
    }

    clickevent (){
      
        cy.get(':nth-child(2) > .oxd-grid-3 > :nth-child(1)').type('2') 
        cy.get(':nth-child(1) > .oxd-input-group > :nth-child(2) > .oxd-select-wrapper > .oxd-select-text > .oxd-select-text--after > .oxd-icon').click()
    }
}

export default Testclaim ;


