class Recruit {

clickRec (){


    cy.get(':nth-child(5) > .oxd-main-menu-item > .oxd-text').click ()

}

 clickadd (){
    cy.get('.orangehrm-header-container > .oxd-button').click ()
 }
   
 clickFname (){
    cy.get('.--name-grouped-field > :nth-child(1) > :nth-child(2) > .oxd-input').type('Test')
 }

    clickMname (){
        cy.get(':nth-child(2) > :nth-child(2) > .oxd-input').type("2")
    }

    clickLname (){

        cy.get(':nth-child(3) > :nth-child(2) > .oxd-input').type("test")


    }

    clickdop (){
        cy.get('.oxd-select-text--after > .oxd-icon').type ("2");
        cy.get(':nth-child(3) > span').click();
    }

    clickEmail (){

        cy.get(':nth-child(3) > .oxd-grid-3 > :nth-child(1) > .oxd-input-group > :nth-child(2) > .oxd-input').type("a@gmail.com")
    }
         
    clickCbox (){
        cy.get('.oxd-checkbox-wrapper > label').click ();
    }

    clicksave (){
        cy.get('.oxd-button--secondary') .click ();
      }
}


export default Recruit;  