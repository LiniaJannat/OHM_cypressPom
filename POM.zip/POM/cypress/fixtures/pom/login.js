
class Login {

    SetUsername (username){

cy.get ("input[placeholder='Username']").type ('Admin')


}

SetPassword () {

    cy.get ("input[placeholder='Password']").type ('admin123')
}

Clicklog (){

    cy.get ("button[type='submit']").click ()
}




}



export default Login;

